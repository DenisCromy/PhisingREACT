import Cabecalho from '../../components/cabecalho';
import './index.scss';

export default function App() {
    return (
        <main className='pagina-app'>
            <Cabecalho />

            <header className='home-principal'>
                <div className='card'>
                    <div className='card-texts'>
                        <h6>Crie uma senha forte</h6>
                        <p>Sua senha precisa ter pelo menos 6 caracteres e incluir uma combinação de números, letras e caracteres especiais (!$@％).</p>
                    </div>

                    <div>

                        <input type='text' placeholder='Senha antiga' />
                        <input type='text' placeholder='Nova senha' />
                        <input type='text' placeholder='Repita a nova senha' />
                    </div>

                    <div>
                        <button>Redefinir senha</button>
                    </div>
                </div>
            </header>
        </main>
    )
}